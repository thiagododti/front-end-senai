# Exercicios HTML2

## Pasta com a lista de exercicios html2 para a aula de Front-End do Senai
